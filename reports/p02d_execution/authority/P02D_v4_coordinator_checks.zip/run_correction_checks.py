"""Run supplied correction tests without importing torch or building a new plan.
The only test scaffolding substitution reads the submitted immutable plan.
Clock/FakeWorker are compiled unchanged from their supplied class definitions.
No production function is replaced by this harness.
"""
import ast, importlib.util, os, sys, types, unittest
from pathlib import Path
root=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(root/'src'))
os.environ['PYTHONPATH']=str(root/'src')
from taskcognition.artifacts import read_json
from taskcognition.p02d_features import gate_vector
from taskcognition.p02d_plan import PLAN_DIR
stub=types.ModuleType('test_p02d')
stub.ROOT=root
stub.read_json=read_json
stub.PLAN_DIR=PLAN_DIR
stub.gate_vector=gate_vector
stub.module=types.SimpleNamespace(candidate=lambda root:read_json(root/PLAN_DIR/'run_plan.json'))
tree=ast.parse((root/'tests/test_p02d.py').read_text())
classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name in ('Clock','FakeWorker')]
exec(compile(ast.Module(body=classes,type_ignores=[]),'supplied-test-scaffolding','exec'),stub.__dict__)
sys.modules['test_p02d']=stub
spec=importlib.util.spec_from_file_location('correction_tests',root/'tests/test_p02d_corrections.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
res=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(mod))
sys.exit(0 if res.wasSuccessful() else 1)
