"""Read-only coordinator checks; no model/torch/transformers imports or work.

Arguments: combined evidence root, execution packet root, pinned tokenizer.json,
output JSON. Combined root uses hash-matched archived dependencies only.
"""
import sys, json, hashlib, math
from pathlib import Path
from collections import Counter
from statistics import mean

root, packet, tokenizer_path, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(root / 'src'))
from taskcognition.contracts import digest
from taskcognition.p02d_reporting import report
from taskcognition.p02_native import native_dataset, syntax
from taskcognition.p01_parsing import parse_and_score

def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

run = root / 'artifacts/development/p02d-cr01-tranche'
planroot = root / 'artifacts/development/p02d-cr01-plan-v4'
plan = read(planroot / 'run_plan.json')
idx = read(packet / 'reports/p02d_execution/P02D_execution_evidence_index.json')
assert all(sha(packet / n) == h for n, h in idx['files'].items())
archived = read(packet / 'reports/p02d_execution/production_execution_report.json')
assert report(root, plan) == archived

# Independently decode this pinned ByteLevel vocabulary; do not re-encode or
# invoke a model. Special tokens are literal strings outside byte decoding.
tok = read(tokenizer_path)
assert sha(tokenizer_path) == plan['environment']['model_files']['tokenizer.json']['sha256']
assert tok['decoder']['type'] == 'ByteLevel'
vocab = {v:k for k,v in tok['model']['vocab'].items()}
special = {t['id']:t['content'] for t in tok['added_tokens']}
bs = list(range(33,127)) + list(range(161,173)) + list(range(174,256))
cs = list(bs)
for b in range(256):
    if b not in bs:
        bs.append(b); cs.append(256 + len(cs) - 188)
byte_inverse = {chr(c):b for b,c in zip(bs,cs)}
assert len(byte_inverse) == 256
def decode(ids):
    parts=[]; buf=bytearray()
    for i in ids:
        if i in special:
            parts.append(buf.decode('utf-8',errors='replace')); buf.clear()
            parts.append(special[i])
        else:
            buf.extend(byte_inverse[c] for c in vocab[i])
    parts.append(buf.decode('utf-8',errors='replace'))
    return ''.join(parts)

raws={}; datasets={}; entries={}; cells={}
for q in plan['requests']:
    slot=q['slot_id']; req=read(planroot/'requests'/f'{slot}.json')
    raw=read(run/'results'/f'{slot}.json'); raws[slot]=raw
    assert digest(req)==q['request_hash']==raw['request_hash']
    assert raw==read(run/'workers'/slot/'results'/f'{slot}.json')
    assert raw['generated_tokens']==len(raw['raw_token_ids'])<=2048
    assert decode(raw['raw_token_ids'])==raw['raw_decoded_text']
    ids=list(raw['raw_token_ids']); terminal=raw['removed_terminal_eos_id']
    if terminal is not None: assert ids.pop()==terminal
    text=decode(ids)
    assert text==raw['parsed']['raw_decoded_text']
    key=(req['family'],req['dataset_index'])
    if key not in entries:
        ds=native_dataset(root,req['family'],req['dataset_config'])
        datasets[key]=ds; entries[key]=ds[req['dataset_index']]
        assert digest(entries[key])==req['entry_hash']
    parsed=parse_and_score(text,req['mode'],req['opening_in_prompt'],raw['finish_reason'],
        lambda payload:datasets[key].score_answer(payload,entries[key]),
        syntax_fn=lambda payload:syntax(req['family'],payload))
    assert parsed==raw['parsed'],slot
    cells.setdefault((req['family'],req['mode']),[]).append(raw)

previous=None; events=[]
for i,p in enumerate(sorted((run/'ledger').glob('*.json'))):
    e=read(p); assert p.name==f'{i:06d}.json' and e['previous_sha256']==previous
    events.append(e);previous=sha(p)
counts=Counter(e['event'] for e in events)
assert counts['dispatch']==counts['admitted']==counts['result']==242
assert counts['session_start']==counts['session_end']==193
last_feature_result=max(i for i,e in enumerate(events) if e['event']=='result' and e['slot_id'].startswith('feature'))
feature_end=next(i for i,e in enumerate(events) if e['event']=='session_end' and e['session_id']=='features')
first_answer=min(i for i,e in enumerate(events) if e['event']=='dispatch' and e['slot_id'].startswith('answer'))
assert last_feature_result<feature_end<first_answer
resources=[read(p) for p in sorted((run/'session_resources').glob('*.json'))]
assert all(r['safe_stopped'] and r['classification']=='COMPLETE' and r['exit_code']==0 for r in resources)
account=read(packet/'reports/p02d_execution/execution_accounting.json')
residency=sum(r['seconds'] for r in resources)
assert math.isclose(residency,account['worker_residency_seconds'])
assert sum(r['generated_tokens'] for r in raws.values())==129371

derived=[]
for item in plan['inputs']:
    modes={m:[raws[q['slot_id']]['parsed']['native_score'] for q in plan['requests'] if q['input_id']==item['input_id'] and q['mode']==m] for m in ('D','R')}
    assert all(len(x)==4 for x in modes.values())
    pd=sum(x==1 for x in modes['D'])/4; pr=sum(x==1 for x in modes['R'])/4
    benefit=mean(modes['R'])-mean(modes['D']); harm=pd*(1-pr)
    target=next(c['targets'] for c in archived['clusters'] if c['input_id']==item['input_id'])
    assert target['benefit']==benefit and target['joint_spoilage']==harm
    assert target['direct_redraw']==4/3*pd*(1-pd)
    for eps,name in ((.1,'decline_010'),(.25,'decline_025')):
        assert target[name]==sum(d-r>=eps for d in modes['D'] for r in modes['R'])/16
    derived.append(dict(input_id=item['input_id'],family=item['family'],pd=pd,pr=pr,benefit=benefit,harm=harm))

all_exposure=mean(c['pd'] for c in derived)
positive_benefit=[c for c in derived if c['benefit']>0]
positive_exposure=sum(c['pd'] for c in positive_benefit)/24
summary=dict(status='PASS',evidence_kind='offline_coordinator_check',indexed_files_verified=len(idx['files']),
    production_report_exact_match=True,raw_token_decodes_and_native_rescores=192,native_entry_hash_matches=len(entries),
    ledger_events=len(events),ledger_event_counts=dict(counts),feature_before_answer=True,
    completed_sessions=len(resources),worker_seconds=residency,known_output_tokens=129371,
    unique_seeds=len({q['sampling_seed'] for q in plan['requests']}),
    complete_clusters=24,zero_harm_clusters=sum(c['harm']==0 for c in derived),
    positive_direct_inputs=sum(c['pd']>0 for c in derived),all_route_B=all_exposure,
    empirical_positive_benefit_inputs=len(positive_benefit),empirical_positive_benefit_B=positive_exposure,
    empirical_positive_benefit_direct_successes=4*sum(c['pd'] for c in positive_benefit),
    mode_totals={m:dict(perfect=sum(r['parsed']['perfect_correct'] for (f,mode),rows in cells.items() if mode==m for r in rows),
        strict_valid=sum(r['parsed']['strict_valid_final'] for (f,mode),rows in cells.items() if mode==m for r in rows),
        tokens=sum(r['generated_tokens'] for (f,mode),rows in cells.items() if mode==m for r in rows)) for m in ('D','R')},
    clusters=derived,torch_imported='torch' in sys.modules,transformers_imported='transformers' in sys.modules,
    new_model_work=0,
    limitations=['No independent Windows/GPU execution or model-weight verification.',
      'Reconstruction uses archived hash-matched source/dependencies; workstation runtime installation is not replicated.',
      'Native scorer checks use pinned source; local NumPy version may differ from workstation.',
      'Empirical positive-benefit selection is outcome-informed diagnostic only, not a fitted gate or deployment.'])
assert not summary['torch_imported'] and not summary['transformers_imported']
output.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='clusters'},indent=2))
