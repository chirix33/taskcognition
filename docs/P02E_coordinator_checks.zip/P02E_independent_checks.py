"""Independent offline checks of P02E arithmetic and packet bindings.

Usage: python P02E_independent_checks.py WORKSPACE OUTPUT_JSON
No model libraries, production analysis helpers, or mutable evidence writes.
"""
import csv, hashlib, json, math, sys, zipfile
from pathlib import Path
from statistics import mean, variance

base=Path(sys.argv[1]); out=Path(sys.argv[2]); root=base/'p02e_review'
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def close(a,b): assert math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-9),(a,b)
receipt=read(base/'upload/P02E_packet_receipt.json')
assert sha(base/'upload/P02E_review_packet.zip')==receipt['zip_sha256']
index=root/'reports/p02e/P02E_evidence_index.json'
assert sha(index)==receipt['index_sha256']
files=read(index)['files']; assert len(files)==63
for n,h in files.items(): assert sha(root/n)==h,n
for uploaded,archived,key in [('P02E_completion.md','reports/phases/P02E_completion.md','completion_sha256'),
 ('offline_design_report.md','reports/p02e/offline_design_report.md','design_report_sha256'),
 ('next_step_proposal.md','reports/p02e/next_step_proposal.md','proposal_sha256')]:
 assert sha(base/'upload'/uploaded)==sha(root/archived)==receipt[key]
with zipfile.ZipFile(base/'upload/P02D_execution_review_packet.zip') as z:
 oldindex=json.loads(z.read('reports/p02d_execution/P02D_execution_evidence_index.json'))['files']
 assert len(oldindex)==8997
 for n,h in oldindex.items(): assert hashlib.sha256(z.read(n)).hexdigest()==h,n

p=root/'reports/p02e'; raw=read(base/'p02d_execution_review/reports/p02d_execution/production_execution_report.json')
clusters=read(p/'cluster_rows.json')['rows']; assert len(clusters)==24
for c in clusters:
 obs=[o for o in raw['observations'] if o['input_id']==c['input_id']]
 for mode in ('D','R'):
  selected=sorted((o for o in obs if o['mode']==mode),key=lambda o:o['draw_index'])
  scores=[o['native_score'] for o in selected]; assert len(scores)==4
  assert scores==c['scores_'+mode]
  close(mean(scores),c['mean_'+mode]);close(variance(scores),c['variance_'+mode])
  close(mean(s==1 for s in scores),c['perfect_rate_'+mode])
 close(c['benefit'],c['mean_R']-c['mean_D'])
 close(c['joint_spoilage'],c['perfect_rate_D']*(1-c['perfect_rate_R']))
rules=read(p/'diagnostic_rules.json')['rules']
actions={'always_D':lambda c:0,'always_R':lambda c:1,
 'observed_positive_benefit':lambda c:int(c['benefit']>0),
 'complement_positive_benefit':lambda c:int(c['benefit']<=0)}
moments={}
for r in rules:
 g=[actions[r['rule']](c) for c in clusters]
 B=[a*c['perfect_rate_D'] for a,c in zip(g,clusters)]
 d=[a*c['benefit'] for a,c in zip(g,clusters)]
 close(mean(B),r['weighted_exposure_B']);close(mean(g),r['weighted_routing_rate'])
 assert sum(g)==r['selected_input_count']
 if sum(B):close(sum(B)**2/sum(b*b for b in B),r['kish_concentration'])
 else:assert r['conditional_spoilage'] is None and r['kish_concentration'] is None
 close(mean((1-a)*c['worker_mean_D']+a*c['worker_mean_R'] for a,c in zip(g,clusters)),r['selected_answer_worker_proxy_seconds'])
 moments[r['rule']]=(mean(B),variance(B),mean(d),variance(d))
L=math.log(40); A=7*L/3
def rad(n,v,w):return math.sqrt(2*v*L/n)+w*A/(n-1)
rows=list(csv.DictReader((p/'analytical_scenarios.csv').open()))
assert len(rows)==168
for r in rows:
 B,v,d,dv=moments[r['rule']];n=int(r['n']);a=float(r['alpha'])
 close(float(r['B_lower_expression']),B-rad(n,v,1))
 close(float(r['Z_upper_expression']),-a*B+rad(n,a*a*v,1))
 close(float(r['Delta_lower_expression']),d-rad(n,dv,2))
con=read(p/'analytical_constraints.json')
for r in con['necessary_conditions']:
 B=moments[r['rule']][0];a=r['alpha'];b=r['b_min']
 for product,label in [(a*B,'zero_harm'),(max(0,B-b),'denominator')]:
  if product:
   exact=1+A/product;close(exact,r[label+'_range_only_n_min'])
   assert 6*math.ceil(exact/6)==r[label+'_range_only_balanced_n_min']
  else:assert r[label+'_range_only_n_min'] is None
for r in con['rare_event_examples']:
 pd,pr,k=r['p_D'],r['p_R'],r['K']
 # Complement form independently verifies the reported union probability.
 close(1-(1-(1-pd)**k)*(1-pr**k),r['probability_empirical_harm_zero'])
 close(pd*(1-pr),r['true_harm'])
cost=read(p/'cost_reconciliation.json');parts=cost['partition']
buckets=['load_components','generation_and_forward_components','cpu_feature_component','cleanup_components','unallocated_within_residency','outside_residency_in_execution_wall']
close(sum(parts[k] for k in buckets),12836.8229112)
close(sum(parts[k] for k in buckets[:-1]),11560.2217413)
sessions=list(csv.DictReader((p/'cost_sessions.csv').open()));assert len(sessions)==192
for s in sessions:
 close(float(s['worker_minus_load_minus_generation']),float(s['worker_seconds'])-float(s['load_seconds'])-float(s['generation_seconds']))
scale=list(csv.DictReader((p/'longer_study_resource_scenarios.csv').open()));assert len(scale)==10
summary=read(p/'summary.json')
for r in scale:
 calls=2*int(r['K_placeholder'])*(2250+int(r['audit_n_placeholder']))
 assert calls==int(r['answer_calls']);assert 2048*calls==int(r['max_output_tokens'])
 close(calls*summary['allround_answer_worker_mean']/3600,float(r['hours_flat_allround_worker_proxy']))
proposal=read(p/'next_step_proposal.json')['contingent_calibration']
assert proposal['total_answer_calls']==24 and proposal['feature_forwards']==26
assert proposal['max_output_tokens']==24*2048 and proposal['feature_positions_max']==26*2048
result=dict(status='PASS',review_date_local='2026-10-17 America/Chicago',new_packet_indexed_files=63,
 historical_packet_files_rehashed=8997,clusters_checked=24,diagnostic_rules=4,analytical_scenarios=168,
 necessary_condition_rows=len(con['necessary_conditions']),rare_event_examples=len(con['rare_event_examples']),
 cost_sessions=192,resource_scale_scenarios=10,proposal_counts_reconciled=True,new_model_work=0,
 scope='Offline integrity/arithmetic checks, not a theorem proof, GPU rerun, gate comparison or final audit.')
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
